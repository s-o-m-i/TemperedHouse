import HomePage from '@/components/home/HomePage'
import React from 'react'

const page = () => {
  return (
    <div>
      <HomePage />
    </div>
  )
}

export default page
