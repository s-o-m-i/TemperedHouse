import React from 'react'
import ServicesPage from "../../components/services"

const Services = () => {
  return (
    <div>
      <ServicesPage/>
    </div>
  )
}

export default Services
