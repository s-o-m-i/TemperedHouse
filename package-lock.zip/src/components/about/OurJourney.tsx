import React from 'react'

const OurJourney = () => {
  return (
    <div>OurJourney</div>
  )
}

export default OurJourney