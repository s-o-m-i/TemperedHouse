import React from 'react'

const Companies = () => {
  return (
    <div>
        <section className="py-20 px-8 md:px-16 bg-white">
            
         </section>
    </div>
  )
}

export default Companies
