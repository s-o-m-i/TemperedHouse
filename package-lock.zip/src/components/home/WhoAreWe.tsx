import React from 'react'

const WhoAreWe = () => {
  return (
    <div>
         <section className="pb-20 relative  h-screen px-8 md:px-16 bg-[#9F1940] bg-pattern">
            <div className="grid grid-cols-2">
                
            </div>
         </section>
    </div>
  )
}

export default WhoAreWe
