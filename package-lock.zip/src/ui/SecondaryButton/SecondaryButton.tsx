import React from 'react'
import './SecondaryButton.css'
const SecondaryButton = () => {
  return (
    <div>
<button className='sec-button rounded-full text-[16px]'>
  <span> Talk to us
  </span>
</button>
    </div>
  )
}

export default SecondaryButton
