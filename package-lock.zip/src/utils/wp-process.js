export const WPProcessStepsData = [
  {
    icon: "requirements",
    title: "Requirements Gathering",
  },
  {
    icon: "design",
    title: "UI/UX Design",
  },
  {
    icon: "development",
    title: "Development",
  },
  {
    icon: "testing",
    title: "Testing",
  },
  {
    icon: "deployment",
    title: "Deployment",
  },
  {
    icon: "support",
    title: "Support & Maintenance",
  },
];
  